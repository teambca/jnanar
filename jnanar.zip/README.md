# Jnanar

A web augmented reality library. Highlighted features include:

:star: Support Image tracking and Face tracking. 

:star: Written in pure javascript, end-to-end from the underlying computer vision engine to frontend

:star: Utilize gpu (through webgl) and web worker for performance

:star: Developer friendly. Easy to setup.

